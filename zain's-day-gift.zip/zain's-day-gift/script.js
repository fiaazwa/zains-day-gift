function popBalloons() {
    const container = document.getElementById("balloons");
    for (let i = 0; i < 10; i++) {
        const balloon = document.createElement("div");
        balloon.classList.add("balloon");

        // Random color & left position
        const colors = ['#ff7675', '#74b9ff', '#ffeaa7', '#55efc4', '#fd79a8'];
        balloon.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        balloon.style.left = Math.random() * 90 + "%";

        container.appendChild(balloon);

        // Remove after animation ends
        setTimeout(() => {
            container.removeChild(balloon);
        }, 5000);
    }
}